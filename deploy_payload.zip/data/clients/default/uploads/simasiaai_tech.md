# simasiaAI Technical

simasiaAI · Technical — Neuro-symbolic RAG for Greek regulated domains 

simasia AI · /tech 
← Marketing Stack Neuro-symbolic Eval Technical contact 

Engineering brief · v1 · June 2026 

Neuro-symbolic RAG infrastructure 
for Greek regulated domains . 

Hybrid retrieval (FAISS 3072-dim Gemini embeddings + TF-IDF). Multi-provider LLM orchestration with 12-combo failover. Symbolic guardrails before and after every model call. Greek-first preprocessing (NFC normalization, acronym expansion). Reviewer-graded evaluation harness. 

01 Stack overview 

Production stack running MYRTO (cancer-patient navigation, Κάπα3) and MyrtoFly (cancer-aware airport companion, Digital Gate V pilot). 

UI layer FastAPI HTML + SSE streaming · multi-language chat history · STT/TTS 
Citation `[N]` rendering · clickable source links · markdown coercer 

▼ 

Orchestration router(query) → safety_filter → query_expansion → hybrid_retrieval → llm → post_process 
Every step is testable in isolation; failures don't cascade 

▼ 

Retrieval FAISS(3072-dim Gemini) ∪ TF-IDF · top_k=25 · MMR diversification 
Embedding cache 41K+ vectors · acronym query expansion for ΚΕΑ/ΚΕΠΑ/ΕΟΠΥΥ 

▼ 

LLM layer UniversalLLMManager · model-agnostic · 12-combo failover · panic-reset pass 
Gemini 2.5-flash-lite / flash / pro · multi-key rotation · 60s timeout · graceful PROHIBITED_CONTENT 

▼ 

Safety 7-category regex crisis triggers · runs before LLM · deterministic hotline injection 
Citation enforcer post-processor · source whitelist filter · NFC-aware SKIP_FILES 

▼ 

Data ingestion Multi-site scraper (per-host allowlist) · auto-PDF download · NFC dedup 
Sources: kapa3.gr · opeka.gov.gr · epan.gov.gr · aade.gr · 1.297 local docs 

02 Retrieval — beyond textbook RAG 

Standard RAG fails on Greek because tokenizers and embeddings are English-first. We diverge on three axes: 

embeddings 

Gemini text-embedding-001 · 3072-dim 

Multilingual model where MiniLM/SBERT fail on Greek proper nouns («Ιατρικός Σύλλογος Δράμας»). 51.799 chunks indexed, sub-second retrieval via FAISS IndexFlatIP. 

hybrid 

FAISS ∪ TF-IDF 

Dense for semantic recall, sparse for rare Greek legal terms (ΦΕΚ numbers, ΚΥΑ codes). MMR diversification on union. Both contribute to top_k=25. 

expansion 

Acronym query expansion 

«Τι είναι το ΚΕΑ;» → search for «ΚΕΑ Κοινωνικό Εισόδημα Αλληλεγγύης». Hand-curated list of 8 ambiguous Greek acronyms; preprocessing layer above retrieval. 

grounding 

Citation post-processor 

LLM emits `[N]` markers. Post-processor verifies N maps to an actually-retrieved chunk; unmapped citations are stripped. Hallucinated source impossible. 

03 Neuro-symbolic guardrails 

Pure LLM is probabilistic; deterministic guarantees come from symbolic code. We use symbolic layers on either side of every LLM call. 

Component 

Type 

Guarantee 

crisis_filter() 

7 regex categories 

Always returns 1018 / 166 / 112 — runs before prompt construction 

citation_enforcer() 

Post-processor 

Strips `[N]` markers that don't map to retrieved chunks 

source_whitelist() 

Filter 

Only 1.297 PDFs + 469 web pages can appear as sources. Inventing URL impossible. 

SKIP_FILES + NFC norm 

Indexing-time filter 

Test-set documents excluded from retrieval (anti-Goodhart). NFC-aware: catches macOS APFS NFD encoding silently breaking substring matches. 

graceful_block() 

Symbolic fallback 

If Gemini returns PROHIBITED_CONTENT, canned safe response (not garbage / not silent fail) 

multi_combo_retry() 

Orchestrator 

12 retries (3 models × 4 keys) + panic-reset pass = 0% failure observed over 84-query batch 

Example: crisis trigger 

Pure LLM safety = probabilistic. We replace it with a deterministic pattern match that fires before any model is contacted: 
# services/safety.py — runs before every LLM call CRISIS_PATTERNS = { "suicidality" : r"(?:θέλω να (?:πεθάνω|σκοτωθώ|τελειώσω))|αυτοκτον" , "chest_pain" : r"(?:πόνος|σφί[ξν]ι(?:μο|μο)) στο στήθος|πνίγομαι" , "febrile_neutro" : r"εμπύρετ\w* ουδετεροπεν" , # ... 4 more categories } def crisis_filter (query: str) -> Optional[str]: for tag, pattern in CRISIS_PATTERNS.items(): if re.search(pattern, query, re.IGNORECASE): log.warning( "crisis triggered: %s" , tag) return CRISIS_RESPONSES[tag] # bypasses LLM entirely return None 

04 LLM orchestration 

Vendor-agnostic. Multi-key. Production-tested. 

models 

Priority chain 

gemini-2.5-flash-lite → flash → pro . Switch chains via env var; Anthropic / OpenAI adapters drop in cleanly. 

retries 

12-combo failover 

3 models × 4 keys = 12 combos. Sequential walk respects per-combo 60s cooldown. If all exhausted → panic-reset clears cooldowns + 2s backoff per attempt. 

embeddings 

Key rotation for 429s 

Embedder reads GEMINI_API_KEY_1..10 ; rotates on 429 with exponential backoff (5s → 60s). Never returns zero vectors silently (the silent-failure mode that secretly poisons FAISS). 

safety 

Healthcare-safe filters 

Gemini default safety filters disabled (they over-block medical content). Our own symbolic safety layer handles crisis. Audited safety stance documented for compliance. 

05 Multi-site ingestion + auto-refresh 

Static PDF corpora go stale. Greek legislation changes monthly (myCAR 2024, e-ΚΕΠΑ 2025). Our scraper sweeps configured government portals; new PDFs auto-download with skip-if-exists. 
# services/scraper.py — per-host allowlist prevents over-crawl SITE_CONFIGS = { "kapa3.gr" : { "allow" : None , "deny" : r"/wp-admin" , "depth" : 2}, "epan.gov.gr" : { "allow" : r"^/(e_kepa|faq_ekepa|karta_anapirias|...)" , "depth" : 3}, "aade.gr" : { "allow" : r"hristikos-odigos-gia-...-amea" , "depth" : 2}, "opeka.gov.gr" : { "allow" : r"^/(atoma-me-anapiria|oikogeneia)" , "deny" : r"/category/|/[0-9]{4}/" , "depth" : 3}, } # skip-if-exists check BEFORE network call — resume-safe if os.path.exists(filepath): return { "url" : pdf_url, "cached" : True } 
Result: 4 sites · 469 web pages · 39 fresh PDFs · zero double-downloads on rerun. 

06 Evaluation harness 

We don't claim accuracy — we measure it. 84 representative navigator queries, run end-to-end via the production API, graded by a certified patient navigator. 

49% 

Run 1 GOOD 
(initial deploy) 

64% 

Run 2 GOOD 
(+leakage / prompt) 

75% 

Run 3 GOOD 
(+ΥΛΙΚΟ / gov scrape) 

0 

Gemini failures 
(was 5/84) 

0 

Test-set leakage 
(was 30/84) 

6.1s 

Avg response 
(cache warm) 

Reviewer bundle 

Reviewers receive a self-contained ZIP: Excel with answers + sources + click-through PDF links + the 171 actually-cited source documents. No need to install anything; reviewer evaluates online. 

07 Compliance posture 

GDPR + EU AI Act high-risk classification done up front, not retrofitted. 

GDPR Art.28 DPA 

Template included; signed for active deployments. Anonymized sessions, no PII at rest. 

EU AI Act 

High-risk classification under Annex III (healthcare). DPIA + FRIA documented. 

Audit trail 

Every safety decision is a code path. Blocked prompts persisted to _blocked_prompts/ for review. 

External legal partner 

RYTHMISIS — DPIA, FRIA, classification, decision flowchart, privacy notice. 

Disclaimer enforcement 

Every answer carries «Είμαι βοηθός Τεχνητής Νοημοσύνης» footer via post-processor (not prompt — symbolic guarantee). 

08 What we don't do 

Honest delimiters. 

→ Don't train custom LLMs. We orchestrate frontier models, not pretrain them. 

→ Don't replace doctors / lawyers. Bot has explicit disclaimer + handoff path on every response. 

→ Don't ship ungrounded answers. If retrieval is empty, response says so + suggests escalation. 

→ Don't store PII. Sessions anonymized; queries logged in aggregate only. 

→ Don't lock you into Gemini. Vendor-swappable LLM layer — change provider via env var. 

09 Talk to engineering 

For RFP responses, integration design, compliance reviews, partner discussions. 

info@simasiaai.gr · Back to overview → 

simasiaAI · v1 · Last updated June 2026 

Marketing · info@simasiaai.gr
